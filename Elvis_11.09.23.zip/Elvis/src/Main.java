import java.sql.SQLOutput;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите годы жизни и творчества Элвиса Пресли: ");
        int year = scr.nextInt();
       String message = (year <= 1935? "Элвис еще не родился!" :(year <=1977? "Элвис жив!"
        : "Элвис навсегда в наших сердцах!"));
        System.out.println(message);



    }
}