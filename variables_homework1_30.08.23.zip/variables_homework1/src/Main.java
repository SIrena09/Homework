public class Main {
    public static void main(String[] args) {
     byte myByte = 4;
     short myShort = 56;
     int myNum = 89;
     float myFloatNum = 4.7333436F;
     char myLetter = 'G';
     long myLong = 12121;
     double myDouble = 4.355453532;



    }
}