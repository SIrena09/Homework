import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        char[][] alphabet = new char[6][6];

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                alphabet[i][j] = (char) ('А' + i * 5 + j);
                alphabet[1][0] = 'Ё';
            }
        }
        System.out.println(Arrays.deepToString(alphabet));



            }

        }









//    Создайте двумерный массив и заполните его заглавными буквами
//    русского алфавита. Буква Ё должна быть на своём месте.
