import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите два слова, состоящие из четного количества букв:");
        String word1 = scanner.next();
        String word2 = scanner.next();
        int length1 = word1.length();
        int length2 = word2.length();
        String result = word1.substring(0, length1 / 2) + word2.substring(length2 / 2);
        System.out.println("Результат: " + result);
    }
    }
