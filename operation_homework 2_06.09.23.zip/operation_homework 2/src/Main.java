import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите суммарную стоимость покупок: ");
        double amountpurcheses = scn.nextDouble();
        System.out.println("Введите сумму денег: ");
        double summoney = scn.nextDouble();
        double change = amountpurcheses - summoney;
        double dolar = (int) change;
        double cent = (int)(change*100)%100;
        System.out.println("Сумма сдачи: " + change);

    }
}