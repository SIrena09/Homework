package game;

public enum Sings {
    PAPER,
    SCISSORS,
    ROCK

}
