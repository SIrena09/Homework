import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите номер знака : ");
        int num = scr.nextInt();
        String nameSings = switch (num) {
            case 1 -> "PAPER";
            case 2 -> "SCISSORS";
            case 3 -> "ROCK";
            default -> "нет больше знаков";
        };
        System.out.println(nameSings);

        Random rnd = new Random();
        int num1 = rnd.nextInt(1, 3);
        System.out.println("Выбор компьютера : " + num1);
        String nameSings1 = switch (num1) {
            case 1 -> "PAPER";
            case 2 -> "SCISSORS";
            case 3 -> "ROCK";
            default -> "нет больше знаков";
        };
        System.out.println(nameSings1);

        if (num == num1) {
            System.out.println("У Вас ничья! ");

        } else if (num <= num1 ) {
            System.out.println("Вы проиграли, победил компьютер!");

        } else {
            System.out.println( "Вы победили!");

    }


    }
}