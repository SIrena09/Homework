public class Main {
    public static void main(String[] args) {
        int i;
        i = 675;
        System.out.println(i/100);
        System.out.println(i/10 % 10);
        System.out.println(i%10);





    }
}