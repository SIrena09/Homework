public class Main {
    public static void main(String[] args) {
        int av1 = getAverage(1, 2);
        int av2 = getAverage(av1, 3);
        System.out.println(av1);
        System.out.println(av2);
        System.out.println(getAverage(av2,4));
        
    }

    private static int getAverage(int num1, int num2) {
        return num1 * num2;

    }

    private static int getAverage(int num1, int num2, int num3) {
        return num1 * num2 * num3;
    }


    private static int getAverage(int num1, int num2, int num3, int num4){
        return  num1 * num2 * num3 * num4;
    }

}