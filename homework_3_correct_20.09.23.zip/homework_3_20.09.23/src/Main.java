import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        int[]array = new int[50];
        System.out.println(Arrays.toString(array));


        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random()* 50) +1;

        }
        System.out.println(Arrays.toString(array));


        for (int i = 0; i < array.length; i++) {
            if (i % 2 == 0){
            }
            else{
                array[i] = 0;

            }
            System.out.println(Arrays.toString(array));

            
        }
        Arrays.sort(array);
        System.out.println(Arrays.toString(array));

    }
    }
