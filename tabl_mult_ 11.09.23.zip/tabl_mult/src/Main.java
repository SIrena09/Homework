import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое целое число :");
        int num1 = scr.nextInt();
        System.out.println("Введите второе целое число :");
        int num2 = scr.nextInt();
        System.out.println("Введите результат умножения :");
        int answer = scr.nextInt();
        int res = (num1 * num2);
        System.out.println(res);
        if (answer == res) {
            System.out.println("Правильный ответ!");
        }else if (answer != res){
            System.out.println(" Ответ не правильный, результат умножения: " +res);






         }
    }
}