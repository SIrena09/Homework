import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите первое число :");
        int num1 = sc.nextInt();
        System.out.println("Введите второе число :");
        int num2 = sc.nextInt();
       int res1 = Math.abs(num1 - 10);
       int res2 = Math.abs(num2 - 10);
       if (res1< res2){
           System.out.println(res1);
       }else {
           System.out.println(res2);
       }


    }
}