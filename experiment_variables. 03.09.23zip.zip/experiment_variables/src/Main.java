public class Main {
    public static void main(String[] args) {
        byte a = 127;
        int f = 128;
        float d = 123.45F;
        char c = 'A';
        System.out.println(a);
        System.out.println(a + 1);
        System.out.println(f + d);
        System.out.println(c + 1);






    }
}