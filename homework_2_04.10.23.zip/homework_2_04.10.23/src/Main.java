import cars.Autocar;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
    Autocar cars = new Autocar("Hyundai","Tucson", 2017, "Navi",34000);
    Autocar cars1 = new Autocar("Volkswagen","Tiguan", 2020, "Black",50000);
    Autocar cars2 = new Autocar("BMW","X7", 2023, "Red",5000);

        System.out.println(cars);
        System.out.println(cars1);
        System.out.println(cars2);


        Autocar[]car = {cars, cars1, cars2};
        System.out.println(Arrays.toString(car));// метод Arrays.toString превращает массив в строку и
        // все объекты в данном случае автомобили выводяться через запятую и пробел в строку с помощью
        // переопределяющего метода toString().

    }

}

//    Напишите класс Автомобиль с минимум пятью полями. Переопределите метод toString, чтобы он выводил
//    полное описание автомобиля по его полям. В программе создайте 3 разных автомобиля и выведите каждый из
//    них в консоль.
//    Создайте массив из этих автомобилей. С помощью Arrays.toString() превратите
//    массив в строку и выведите в консоль.
//    Перейдите в код метода Arrays.toString() и посмотрите на его реализацию.
//    В какой момент автомобиль становится строкой внутри этого метода?