package cars;

public class Autocar {
    private String make;
    private String model;
    private int age;
    private String color;
    private int mileage;


    public Autocar(String make, String model, int age, String color, int mileage){
        this.make = make;
        this.model = model;
        this.age = age;
        this.color = color;
        this.mileage = mileage;

    }

    @Override
    public String toString() {
        return "Autocar{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                ", mileage=" + mileage +
                '}';
    }
}

