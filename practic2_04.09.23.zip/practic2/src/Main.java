import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {

        Scanner skanner = new Scanner(System.in);
        System.out.print(" Назовите свое Имя: ");
        String name = skanner.nextLine();
        System.out.print( name + ", " + " Сколько Вам лет:");
        int age = skanner.nextInt();
        System.out.print(" Скажите, пожалуйста, какой ваш вес: ");
        double  weight = skanner.nextDouble();
        System.out.println(" Уважаемый " + name + "," + " в свои " + age + " лет. Вы для нас дороги, как " + weight + " килограмм золота !!!");






    }
}