
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое целое число :  ");
        int num1 = scr.nextInt();
        System.out.println("Введите второе целое число :  ");
        int num2 = scr.nextInt();scr.nextLine();
        int summa = 0;
        String str = "";
        do {
            for (int i = num1; i <= num2; i++) {
                if (i % 2 != 0) {
                    summa += i;
                }

            }
            System.out.println(summa);
            System.out.println("Введите \"quit\" для выхода: ");
            str = scr.nextLine();

        }while (!"qiut".equalsIgnoreCase(str));




        }

    }





