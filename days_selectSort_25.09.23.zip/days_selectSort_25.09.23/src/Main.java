import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        LocalDate date = LocalDate.of(1989, 8, 14);

            System.out.println(date.getDayOfMonth());
            System.out.println(date.getMonth().ordinal() + 1);
            System.out.println(date.getMonthValue());
            System.out.println(date.getYear());


        LocalDate[] dates = {
                LocalDate.of(1989, 8, 14),
                LocalDate.of(2000, 8, 16),
                LocalDate.of(1965, 8, 15),
                LocalDate.of(1999, 8, 13),
                LocalDate.of(1989, 8, 18),
                LocalDate.of(1989, 8, 14)
        };

        Arrays.sort(dates);
        System.out.println(Arrays.toString(dates));
        System.out.println(Arrays.toString(dates));




        boolean isSorted = false;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < dates.length - 1; i++) {
               if (dates[i].getYear() > dates[i + 1].getYear())
                    swapValues(dates, i, i + 1);
               if (dates[i].getDayOfMonth() > dates[i + 1].getDayOfMonth())
                    swapValues(dates, i, i + 1);
               isSorted = false;
                }
            }
        }


        private static void swapValues (LocalDate[]dates,int a, int b){
            LocalDate temp;
            temp = dates[a];
            dates[a] = dates[b];
            dates[b] = temp;
        }

    }
//    Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
//    Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.






