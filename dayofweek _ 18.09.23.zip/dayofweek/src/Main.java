import week.DayOfWeek;

import java.util.Locale;
import java.util.Scanner;

    public class Main {
        public static void main(String[] args) {

            Scanner scanner = new Scanner(System.in);
            System.out.println("Введите текущий день недели : ");
            String nameOfDay = scanner.nextLine().toUpperCase(Locale.ROOT);
            String[] days = {"SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"};
            System.out.println(java.time.DayOfWeek.values());

            for (String day : days) {
                System.out.println(day);

            }
        }

    }







