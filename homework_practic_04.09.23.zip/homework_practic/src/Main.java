import java.sql.SQLOutput;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        byte b= (byte) rnd.nextInt(-128, 127);
        int i = rnd.nextInt(-21474, 21474);
        boolean y = rnd.nextBoolean();
        short s = (short) rnd.nextInt(-32000, 32000);
        float f = rnd.nextFloat(-123.45F, +38F);
        double d = rnd.nextDouble(123.456, 308);
        long l = rnd.nextLong(-922337, 922337);
        char c = (char) rnd.nextInt(45,85);
        System.out.println(b);
        System.out.println(i);
        System.out.println(y);
        System.out.println(s);
        System.out.println(f);
        System.out.println(d);
        System.out.println(l);
        System.out.println(c);

        String x1 = i + " число " + rnd.nextLong() + " очень длинное ";
        String x2 = String.valueOf(rnd.nextInt());
        System.out.println(x1);
        System.out.println(x2);

        String x3 = f +"";
        String x4 = String.valueOf(rnd.nextFloat());
        System.out.println(x3);
        System.out.println(x4);

        String x5 = c + "" + rnd.nextDouble();
        String x6 = String.valueOf(rnd.nextInt('a', 'z') +1);
        System.out.println(x5);
        System.out.println(x6);









    }
}