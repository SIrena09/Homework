public class Main {
    public static void main(String[] args) {
        int i;
        i = 345;
        System.out.println(i/100);
        System.out.println(4%i);
        System.out.println(i/69);
        int a;
        a = 987;
        System.out.println(a/100);
        System.out.println(8%a);
        System.out.println(a/141);





    }
}