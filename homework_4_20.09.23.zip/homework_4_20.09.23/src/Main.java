import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String[] strings = {"abc", "qwerty", "mu", "litr", "dfgh"};
        String min = strings[0];
        String max = strings[0];

        for (int i = 0; i < strings.length; i++) {
            if (min.length() > strings[i].length()) {
                min = strings[i];
            }
            if (max.length() < strings[i].length()) {
                max = strings[i];

            }
        }
        System.out.println("минимальная строка : " + min);
        System.out.println("максимальная строка : " + max);


    }
}

