import PKM.Students;

public class Main {
    public static void main(String[] args) {

        Students students = new Students("John Colin", "Mathematics", 2,75);
        Students other = new Students("Jane Eyre", "Biology", 1,80);
        System.out.println(students.name);
        System.out.println(other.name);
        students.name = "Jane Brown";
        students.setCourse(1);
        students.setMinExamScore(80);
        System.out.println(students.name);
        Students cloneStudents = new Students(students);
        if(students == cloneStudents){
            System.out.println("Это тот же студент ");
        }else {
            System.out.println("Это разные студенты ");
        }

    }
}