package PKM;

public class University {
    public Students createStudent(String name, String faculty, int course, int minExamScore) {
        return new Students(name, faculty, course, minExamScore);
    }
}