package PKM;

public class Students {

    public String name;
   String faculty;
    private int course;
    private int minExamScore;


    public Students(String name, String faculty, int course, int minExamScore) {
        this.name = name;
        this.faculty = faculty;
        this.course = course;
        this.minExamScore = minExamScore;
    }
    public Students(Students other){
        this.name = other.name;
        this.faculty = other.faculty;
        this.minExamScore = other.minExamScore;
        this.course = other.course;
    }


    public int getCourse() {

        return course;
    }

    public void setCourse(int course) {

        this.course = course;
    }

    public int getMinExamScore() {

        return minExamScore;
    }

    public void setMinExamScore(int minExamScore) {

        this.minExamScore = minExamScore;
    }

}



