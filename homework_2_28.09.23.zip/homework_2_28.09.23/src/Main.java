import java.util.Locale;

public class Main {
    public static void main(String[] args) {
String str = new String(" I study Basic Java!");
        System.out.println(str);
        System.out.println(str.charAt(1));
        System.out.println(str.charAt(str.length()-1));
        System.out.println(str.contains("Java"));
        System.out.println(str.replace("a", "o"));
        System.out.println(str.toLowerCase(Locale.ROOT));
        System.out.println(str.toUpperCase(Locale.ROOT));
        System.out.println(str.substring(0, 15));

    }
}








//        Создайте строку через new - I study Basic Java!
//        Напишите метод, который принимает в качестве параметра строку, передайте в этот метод строку, которую создали в п.1
//        Распечатать последний символ строки. Используем метод String.charAt().
//        Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
//        Заменить все символы “а” на “о”.
//        Преобразуйте строку к верхнему регистру.
//        Преобразуйте строку к нижнему регистру.
//        Вырезать строку Java c помощью метода String.substring().