import week.DayOfWeek;

import java.util.Locale;
import java.util.Scanner;

    public class Main {
        public static void main(String[] args) {

            Scanner scanner = new Scanner(System.in);
            System.out.println("Введите текущий день недели : ");
            String nameOfDay = scanner.nextLine().toUpperCase(Locale.ROOT);
            DayOfWeek userChoise = DayOfWeek.valueOf(nameOfDay);

            for (DayOfWeek day : DayOfWeek.values())  {
                if(userChoise != day);
                System.out.println(day);

            }

        }

    }







