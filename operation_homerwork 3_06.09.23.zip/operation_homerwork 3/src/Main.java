public class Main {
    public static void main(String[] args) {
       boolean isYearFinished = true;
       boolean isGoodWeather = true;
       boolean isBoughtRaincoats = true;
       boolean isJymFree = true;
       boolean isKateComeBack = true;
       boolean isTravelHappend = (isYearFinished || isGoodWeather && isBoughtRaincoats) && (isJymFree ^ isKateComeBack)
               && (isKateComeBack ^ isJymFree);
        System.out.println(isTravelHappend);


    }
}