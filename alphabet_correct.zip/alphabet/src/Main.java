import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        char[][] alphabet = new char[6][6];
        char letter = 'А';

        for (int i = 0; i < alphabet.length; i++) {
            for (int j = 0; j < alphabet[i].length; j++) {
                alphabet[i][j] = letter;
                letter++;
               if(letter >'Я')break;
               if(letter == 'Ж'){
                   if(j < alphabet[i].length -1)
                       j++;
                   else{
                       j = 0;
                       i++;
                   }

                   alphabet[i][j] = 'Ё';
               }
            }
        }
        System.out.println(Arrays.deepToString(alphabet));



            }

        }









//    Создайте двумерный массив и заполните его заглавными буквами
//    русского алфавита. Буква Ё должна быть на своём месте.
