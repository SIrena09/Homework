public class Main {
    public static void main(String[] args) {
       boolean isYearFinished = true;
       boolean isGoodWeather = false;
       boolean isBoughtRaincoats = false;
       boolean isJymFree = true;
       boolean isKateComeBack = true;
       boolean isTravelHappend = isYearFinished && (isGoodWeather || isBoughtRaincoats) && isJymFree != isKateComeBack;
        System.out.println(isTravelHappend);


    }
}