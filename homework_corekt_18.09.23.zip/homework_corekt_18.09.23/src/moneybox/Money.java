package moneybox;

public enum Money {
    FIFTY,
    ONEHUNDRED,
    TWOHUNDRED,
    FIVEHUNDRED
}
