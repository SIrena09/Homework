import moneybox.Money;

import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {

       int money [] = new int[]{50, 100, 200, 500};
       int summa = 0;
        Random rnd = new Random(money.length);
            do {
                summa += money[(rnd.nextInt(money.length))];

            } while (summa <= 10000);
        System.out.println(" У меня есть нужная сумма : " + summa);
        System.out.println(" Ура! Друзья, идем в лучший бар города!");

        }


    }

