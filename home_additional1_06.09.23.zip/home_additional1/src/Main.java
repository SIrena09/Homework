import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner src = new Scanner(System.in);
        System.out.println("Введите целое число: ");
        int number = src.nextInt();
        System.out.println( number >> 1);

    }
}