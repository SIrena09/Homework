import wedding.WeddingAnniwersary;

import java.lang.management.ThreadInfo;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите сколько лет Вы в браке: ");
        int numWedding = scr.nextInt()+1;
        System.out.println("следующая годовщина : " + numWedding);
       String nameWedding = switch (numWedding){
            case 10 -> "TIN";
            case 11 -> "STEEL";
            case 12 -> "SILK";
            case 13 -> "LACE";
            case 14 -> "IVORY";
            case 15 -> "CRYSTAL";
            default -> "не отмечается";
        };
        System.out.println(nameWedding);


    }
}