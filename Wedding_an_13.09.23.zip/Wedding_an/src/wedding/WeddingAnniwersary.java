package wedding;

public enum WeddingAnniwersary {
    TIN,
    STEEL,
    SILK,
    LACE,
    IVORY,
    CRYSTAL
}
