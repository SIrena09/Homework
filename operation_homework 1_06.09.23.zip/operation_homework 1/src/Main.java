public class Main {
    public static void main(String[] args) {
        double meter = 150;
        System.out.println("В километрах:" + meter/1000);
        System.out.println("В футах:" + meter*3.28);
        System.out.println("В милях:" + meter*0.00062137);
        System.out.println("В аршинах:" + meter*1.406);
    }
}