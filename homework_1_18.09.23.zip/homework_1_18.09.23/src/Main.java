import java.util.Random;

public class Main {
    public static void main(String[] args) {

        int sum = 0;
        int a = 50;
        int b = 100;
        int c = 200;
        int d = 500;
        int result = 10000;
        Random rnd = new Random();

        while (result > sum){
            int randomChoise = rnd.nextInt(0,5);
            switch (randomChoise){
                case 1 -> sum +=a;
                case 2 -> sum +=b;
                case 3 -> sum +=c;
                default -> sum +=d;
            }
            System.out.println("Спасибо, у меня уже " + sum  + "$");
        }
        System.out.println("Ура! Пойдемте в бар.");

    }
}