package utilmath;

public class MathUtil {
    private MathUtil() {}

    public static double addAll(double... numbers) {
        double sum = 0;
        for (double number : numbers) {
            sum += number;
        }
        return sum;
    }

    public static double minusAll(double initial, double... numbers) {
        for (double number : numbers) {
            initial -= number;
        }
        return initial;
    }

    public static double multAll(double... numbers) {
        double product = 1;
        for (double number : numbers) {
            product *= number;
        }
        return product;
    }

    public static double powAll(double base, double... exponents) {
        for (double exponent : exponents) {
            base = Math.pow(base, exponent);
        }
        return base;
    }

}

//    Создайте утилитарный класс, который будет аналогом класса Math.
//    В нём будет один приватный конструктор, а также только статические методы:
//        addAll - сложение неограниченного числа аргументов
//        minusAll – принимает исходное число и неограниченный набор аргументов,
//        которые нужно вычесть из исходного числа
//        multAll – перемножает все данные аргументы
//        powAll – принимает исходное число-основание и
//        неограниченный набор аргументов степеней.
//        Нужно последовательно возвести основание во все степени.
//        Используйте все методы в коде метода main.

