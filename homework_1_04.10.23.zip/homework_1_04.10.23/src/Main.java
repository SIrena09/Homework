import utilmath.MathUtil;

public class Main {
    public static void main(String[] args) {
        System.out.println(MathUtil.addAll(1, 2, 3, 4));
        System.out.println(MathUtil.minusAll(10, 2, 3));
        System.out.println(MathUtil.multAll(1, 2, 3));
        System.out.println(MathUtil.powAll(2, 3, 4));
    }
}

