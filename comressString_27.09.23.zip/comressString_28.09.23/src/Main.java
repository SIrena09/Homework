

public class Main {
    public static void main(String[] args) {
        String str = "AAAABBBCCCDDEG";
        StringBuilder sb = new StringBuilder();
        int count = 1;
        for (int i = 1; i < str.length(); i++) {
            if (str.charAt(i) == str.charAt(i - 1)) {
                count++;
            } else {
                sb.append(str.charAt(i - 1));
                sb.append(count < 2 ?  "" : + count);
                count = 1;

            }
        }
        sb.append(str.charAt(str.length() - 1));
        sb.append(count < 2 ?  "" : + count);
        String result = sb.toString();
        System.out.println(result);
    }


    }












//    дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
//    Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой.
//     Если буква одна, то цифра не ставится.


